
import streamlit as st
import json
from datetime import date

st.set_page_config(page_title='Artificial Consciousness Plan', layout='wide')

def load_logs():
    try:
        with open('introspection_logs.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_logs(logs):
    with open('introspection_logs.json', 'w') as f:
        json.dump(logs, f, indent=4)

def home():
    st.markdown("""
    <style>
    .main { background-color: #1F2B3E; color: white; }
    h1, h2, h3 { color: #4C8BE2; }
    </style>
    """, unsafe_allow_html=True)

    st.title("🚀 Super Plan to Build Artificial Consciousness & Power Network")
    st.markdown("""
    This plan is your roadmap to developing real artificial consciousness and becoming a world-shaping force.

    ### 📌 Pillars of the Plan
    - **Technical Mastery**: From robotics to neuroscience to self-aware agents.
    - **Power Network**: Build connections with top minds in intelligence, medicine, and power.
    - **Inner Evolution**: Shape your character to be a visionary, strategic, and emotionally wise leader.

    _Daily commitment, introspection, and strategic networking will fuel your journey._
    """)

def introspection():
    st.title("🧠 Daily Introspection Prompts")
    prompts = [
        "What did I build or learn today that moved me closer to artificial consciousness?",
        "Did I reach out to, or engage with, people smarter or more powerful than me?",
        "What emotion did I experience today that taught me something about myself or consciousness?",
        "Did I act today like someone who could shape the future of humanity?",
        "What did I fear or avoid? Why?",
        "If I met the most powerful version of myself — what would he say I should do tomorrow?"
    ]

    responses = {}
    today = str(date.today())
    st.subheader(f"Date: {today}")
    for idx, prompt in enumerate(prompts):
        responses[idx] = st.text_area(f"{prompt}", height=100)

    if st.button("💾 Save Today's Introspection"):
        logs = load_logs()
        logs[today] = [{
            "question": prompt,
            "answer": responses[idx]
        } for idx, prompt in enumerate(prompts)]
        save_logs(logs)
        st.success("Saved successfully!")

def review():
    st.title("📅 Review Past Entries")
    logs = load_logs()
    dates = sorted(logs.keys(), reverse=True)
    if not dates:
        st.info("No introspection logs found.")
        return
    selected_date = st.selectbox("Select a date to review:", dates)
    if selected_date:
        st.subheader(f"Entries for {selected_date}")
        for item in logs[selected_date]:
            st.markdown(f"**{item['question']}**")
            st.markdown(f"<div style='background-color:#2F3E56; padding:10px; border-radius:5px;'>{item['answer']}</div>", unsafe_allow_html=True)

# Navigation
page = st.sidebar.selectbox("Go to", ["Home", "Introspection", "Review"])
if page == "Home":
    home()
elif page == "Introspection":
    introspection()
elif page == "Review":
    review()
